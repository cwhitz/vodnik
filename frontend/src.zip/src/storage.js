import JSZip from "jszip";
import { saveAs } from "file-saver";

export async function saveStory(text, mediaMap) {
  const zip = new JSZip();
  zip.file("story.md", text);

  for (const [id, url] of Object.entries(mediaMap)) {
    const response = await fetch(url);
    const blob = await response.blob();
    const ext = blob.type.split("/")[1] || "bin";
    zip.file(`media/${id}.${ext}`, blob);
  }

  const content = await zip.generateAsync({ type: "blob" });
  saveAs(content, "story.zip");
}

export async function loadStory(file, setText, setMediaMap) {
  if (!file) return;

  const zip = await JSZip.loadAsync(file);

  // Load Markdown
  const markdownFile = zip.file("story.md");
  if (markdownFile) {
    const loadedText = await markdownFile.async("string");
    setText(loadedText);
  }

  // Load media
  const mediaFolder = zip.folder("media");
  const newMediaMap = {};

  if (mediaFolder) {
    const files = Object.values(mediaFolder.files);
    for (const f of files) {
      const blob = await f.async("blob");
      const id = f.name.split("/").pop().split(".")[0];
      const url = URL.createObjectURL(blob);
      newMediaMap[id] = url;
    }
  }

  setMediaMap(newMediaMap);
}
