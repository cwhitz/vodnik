export async function generateNextLineAPI(text, additionalInstructions, wordCount) {
  const payload = { text, additional_instructions: additionalInstructions, word_count: wordCount };
  const response = await fetch("http://127.0.0.1:8000/generate/next", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("API request failed");
  const data = await response.json();
  return data.generated_text;
}

export async function generateBetweenAPI(text, additionalInstructions, wordCount, cursorPosition) {
  const payload = {
    text,
    additional_instructions: additionalInstructions,
    word_count: wordCount,
    current_position: cursorPosition,
  };
  const response = await fetch("http://127.0.0.1:8000/generate/between", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });

  if (!response.ok) throw new Error("API request failed");
  const data = await response.json();
  return data.generated_text;
}