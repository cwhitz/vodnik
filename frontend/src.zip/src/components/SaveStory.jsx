import JSZip from "jszip";
import { saveAs } from "file-saver";

export async function saveStory(text, mediaMap, loreItems) {
  const zip = new JSZip();

  // Add story text
  zip.file("story.md", text);

  // Add lore as JSON
  zip.file("lore.json", JSON.stringify(loreItems, null, 2));

  // Add all media files
  for (const [id, url] of Object.entries(mediaMap)) {
    const response = await fetch(url); // fetch Blob from object URL
    const blob = await response.blob();
    const ext = blob.type.split("/")[1] || "bin"; // determine extension
    zip.file(`media/${id}.${ext}`, blob);
  }

  const content = await zip.generateAsync({ type: "blob" });
  saveAs(content, "story.zip");
}