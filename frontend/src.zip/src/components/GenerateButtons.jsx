export default function GenerateButtons({
  onGenerateNext,
  onGenerateAtCursor,
  onUndoLast,
  onRedoLast,
  loading,
}) {
  const renderButtonContent = (text) => (
    loading ? (
  <div className="flex items-center justify-center space-x-1">
    <span className="animate-pulse">.</span>
    <span className="animate-pulse delay-150">.</span>
    <span className="animate-pulse delay-300">.</span>
  </div>
) : (
      text
    )
  );

  return (
    <div className="p-4 flex gap-2 border-t border-neutral-700">
      <button
        className="generate-button flex-1 relative"
        onClick={onGenerateNext}
        disabled={loading}
      >
        {renderButtonContent("Generate next line")}
      </button>

      <button
        className="generate-button flex-1 relative"
        onClick={onGenerateAtCursor}
        disabled={loading}
      >
        {renderButtonContent("Generate at cursor")}
      </button>

      <button
        className="hacker-button w-26 relative"
        onClick={onUndoLast}
        disabled={loading}
        title="Undo AI output"
      >
        {renderButtonContent("Undo ⟲")}
      </button>

      <button
        className="hacker-button w-26 relative"
        onClick={onRedoLast}
        disabled={loading}
        title="Rerun last AI output"
      >
        {renderButtonContent("Redo ↻")}
      </button>
    </div>
  );
}
