import { useState, useEffect } from "react";

export default function Settings({ savedTokens = {}, onSave }) {
  const [openAIApiKey, setOpenAIApiKey] = useState("");
  const [anthropicApiKey, setAnthropicApiKey] = useState("");
  const [xaiApiKey, setXaiApiKey] = useState("");

  // Load saved tokens if provided
  useEffect(() => {
    if (savedTokens.openAI) setOpenAIApiKey(savedTokens.openAI);
    if (savedTokens.anthropic) setAnthropicApiKey(savedTokens.anthropic);
    if (savedTokens.xAI) setXaiApiKey(savedTokens.xAI);
  }, [savedTokens]);

  const handleSave = () => {
    const tokens = {
      openAI: openAIApiKey,
      anthropic: anthropicApiKey,
      xAI: xaiApiKey,
    };
    if (onSave) onSave(tokens);
    alert("API tokens saved!");
  };

  return (
    <div className="p-6 w-full max-w-md mx-auto bg-neutral-900 rounded-xl border border-neutral-700 shadow-lg flex flex-col gap-4">
      <h2 className="text-2xl font-bold text-neutral-200 mb-2">Settings</h2>

      {/* OpenAI */}
      <div className="flex flex-col gap-1">
        <label className="text-neutral-300 font-medium">OpenAI API Key</label>
        <input
          type="password"
          value={openAIApiKey}
          onChange={(e) => setOpenAIApiKey(e.target.value)}
          placeholder="sk-..."
          className="p-2 rounded-lg bg-neutral-800 border border-neutral-700 text-neutral-200 focus:outline-none focus:border-[#6a6ec3]"
        />
      </div>

      {/* Anthropic */}
      <div className="flex flex-col gap-1">
        <label className="text-neutral-300 font-medium">Anthropic API Key</label>
        <input
          type="password"
          value={anthropicApiKey}
          onChange={(e) => setAnthropicApiKey(e.target.value)}
          placeholder="sk-..."
          className="p-2 rounded-lg bg-neutral-800 border border-neutral-700 text-neutral-200 focus:outline-none focus:border-[#6a6ec3]"
        />
      </div>

      {/* xAI */}
      <div className="flex flex-col gap-1">
        <label className="text-neutral-300 font-medium">xAI API Key</label>
        <input
          type="password"
          value={xaiApiKey}
          onChange={(e) => setXaiApiKey(e.target.value)}
          placeholder="sk-..."
          className="p-2 rounded-lg bg-neutral-800 border border-neutral-700 text-neutral-200 focus:outline-none focus:border-[#6a6ec3]"
        />
      </div>

      {/* Save Button */}
      <button
        onClick={handleSave}
        className="mt-4 bg-[#6a6ec3] text-black font-semibold py-2 px-4 rounded-lg hover:bg-[#4d53c4] transition-colors"
      >
        Save
      </button>
    </div>
  );
}
