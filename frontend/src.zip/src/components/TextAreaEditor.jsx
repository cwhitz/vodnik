import { useRef } from "react";

export default function TextAreaEditor({
  text,
  setText,
  additionalInstructions,
  setAdditionalInstructions,
  wordCount,
  setWordCount,
  textareaRef,
  mediaMap,
  setMediaMap,
  loading,
}) {
  function handlePaste(e) {
    const items = e.clipboardData.items;
    for (let item of items) {
      if (item.type.startsWith("image/") || item.type.startsWith("video/")) {
        const file = item.getAsFile();
        const id =
          (item.type.startsWith("image") ? "img" : "vid") + "-" + Date.now();
        const url = URL.createObjectURL(file);
        setMediaMap((prev) => ({ ...prev, [id]: url }));

        const placeholder =
          (item.type.startsWith("image") ? "!" : "") +
          `[pasted ${item.type.split("/")[0]}](${id})`;

        const textarea = textareaRef.current;
        const startPos = textarea.selectionStart;
        const endPos = textarea.selectionEnd;
        const newText =
          text.slice(0, startPos) + placeholder + text.slice(endPos);
        setText(newText);
        e.preventDefault();
      }
    }
  }

  function handleFileUpload(files) {
    Array.from(files).forEach((file) => {
      const id = (file.type.startsWith("image") ? "img" : "vid") + "-" + Date.now();
      const url = URL.createObjectURL(file);
      setMediaMap((prev) => ({ ...prev, [id]: url }));

      const placeholder =
        (file.type.startsWith("image") ? "!" : "") + `[${file.name}](${id})`;
      setText((prev) => prev + "\n" + placeholder);
    });
  }

  return (
    <div className="flex flex-col h-full">
      <textarea
        ref={textareaRef}
        value={text}
        onChange={(e) => setText(e.target.value)}
        onPaste={handlePaste}
        className="w-full h-full p-4 rounded-xl bg-black border border-neutral-700 text-neutral-200 resize-none focus:outline-none focus:border-neutral-500"
        placeholder="Write your story here..."
      />

      <textarea
        className="w-full h-1/4 p-4 rounded-xl bg-neutral-800 border border-neutral-700 text-neutral-300 resize-none focus:outline-none focus:border-neutral-500"
        placeholder="Guide the story..."
        value={additionalInstructions}
        onChange={(e) => setAdditionalInstructions(e.target.value)}
      />

      {/* Word Count */}
      <div className="p-4 flex flex-col gap-2">
        <label htmlFor="wordCount" className="text-neutral-200">
          Word count: {wordCount}
        </label>
        <input
          id="wordCount"
          type="range"
          min={25}
          max={250}
          step={25}
          value={wordCount}
          onChange={(e) => setWordCount(Number(e.target.value))}
          className="w-full"
        />
        <div className="flex justify-between text-sm text-neutral-400">
          <span>just a little</span>
          <span>go crazy</span>
        </div>
      </div>
    </div>
  );
}
