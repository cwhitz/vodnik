export default function TopBar({ setText, setSettingsOpen, saveStory, loadStory }) {
  return (
    <div className="flex items-center justify-between p-4 border-b border-neutral-700 bg-black">
      <div className="flex items-center gap-2">
        <img src="/logo.png" alt="Logo" className="h-10" />
      </div>

      <div className="flex gap-2 relative">
        {/* Save */}
        <button className="hacker-button" onClick={saveStory}>
          Save Story
        </button>

        {/* Load */}
        <input
          id="loadStoryInput"
          type="file"
          accept=".zip"
          onChange={(e) => {
            if (e.target.files.length > 0) {
              loadStory(e.target.files[0]);
            }
          }}
          className="hidden"
        />
        <label htmlFor="loadStoryInput" className="hacker-button cursor-pointer">
          Load Story
        </label>

        {/* Settings Gear */}
        <button
          className="hacker-button ml-2"
          onClick={() => setSettingsOpen(true)}
        >
          ⚙
        </button>
      </div>
    </div>
  );
}
