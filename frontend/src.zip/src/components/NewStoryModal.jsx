import { useState } from "react";
import ReactMarkdown from "react-markdown";

export default function NewStoryModal({ onClose, setText, wordCount }) {
  const [title, setTitle] = useState("");
  const [instructions, setInstructions] = useState("");
  const [preview, setPreview] = useState("");

  async function runNewStory() {
    if (!title.trim()) return;

    try {
      const payload = {
        text: instructions,
        additional_instructions: "",
        word_count: 250,
      };
      const response = await fetch("http://127.0.0.1:8000/generate/start", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });
      if (!response.ok) throw new Error("API request failed");
      const data = await response.json();
      setPreview(data.generated_text || "");
    } catch (err) {
      console.error("Error creating new story:", err);
    }
  }

  function acceptNewStory() {
    setText(preview);
    onClose();
    setTitle("");
    setInstructions("");
    setPreview("");
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-70">
      <div className="bg-neutral-900 rounded-xl w-4/5 h-4/5 flex gap-4 p-6 relative">
        <button
          className="absolute top-2 right-2 text-neutral-200"
          onClick={onClose}
        >
          ✖
        </button>

        {/* Left Column */}
        <div className="flex-1 flex flex-col gap-2">
          <h2 className="text-neutral-200 text-xl mb-2">New Story</h2>
          <input
            className="w-full p-2 rounded bg-neutral-800 text-neutral-200 border border-neutral-700 focus:outline-none"
            placeholder="Story Title / Prompt"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
          />
          <textarea
            className="w-full flex-1 p-2 rounded bg-neutral-800 text-neutral-200 border border-neutral-700 focus:outline-none resize-none"
            placeholder="Optional instructions"
            value={instructions}
            onChange={(e) => setInstructions(e.target.value)}
          />
          <div className="flex gap-2 mt-2">
            <button className="hacker-button flex-1" onClick={runNewStory}>
              Re-run
            </button>
            <button className="hacker-button flex-1" onClick={acceptNewStory}>
              Accept
            </button>
          </div>
        </div>

        {/* Right Column */}
        <div className="flex-1 bg-neutral-800 p-2 rounded overflow-auto">
          <h3 className="text-neutral-200 mb-2">Preview</h3>
          <div className="text-neutral-200 overflow-auto">
            {preview ? (
              <ReactMarkdown>{preview}</ReactMarkdown>
            ) : (
              <p className="opacity-50">
                Generated story preview will appear here...
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
