import { useState } from "react";
import EditorToolbar from "./EditorToolbar";
import NewStoryModal from "./NewStoryModal";
import TextAreaEditor from "./TextAreaEditor";
import GenerateButtons from "./GenerateButtons";
import LoreManager from "./LoreManager";

export default function Editor({
  text,
  setText,
  additionalInstructions,
  setAdditionalInstructions,
  wordCount,
  setWordCount,
  handleGenerateNextLine,
  handleGenerateBetween,
  handleUndoLastGenerated,
  handleRedoLastGenerated,
  mediaMap,
  setMediaMap,
  textareaRef,
  loading,
  loreItems,
  setLoreItems,
}) {
  const [loreOpen, setLoreOpen] = useState(false);
  const [newStoryOpen, setNewStoryOpen] = useState(false);

  return (
    <div className="flex flex-col w-1/2 h-full border-r border-neutral-700 bg-black relative">
      <LoreManager
        isOpen={loreOpen}
        onClose={() => setLoreOpen(false)}
        loreItems={loreItems}
        setLoreItems={setLoreItems}
      />

      <EditorToolbar
        onNewStory={() => setNewStoryOpen(true)}
        onAddMedia={() => document.getElementById("fileUpload")?.click()}
        onEditLore={() => setLoreOpen(true)}
      />

      {newStoryOpen && (
        <NewStoryModal
          onClose={() => setNewStoryOpen(false)}
          setText={setText}
          wordCount={wordCount}
        />
      )}

      <TextAreaEditor
        text={text}
        setText={setText}
        additionalInstructions={additionalInstructions}
        setAdditionalInstructions={setAdditionalInstructions}
        wordCount={wordCount}
        setWordCount={setWordCount}
        textareaRef={textareaRef}
        mediaMap={mediaMap}
        setMediaMap={setMediaMap}
        loading={loading}
      />

      <GenerateButtons
        onGenerateNext={handleGenerateNextLine}
        onGenerateAtCursor={handleGenerateBetween}
        onUndoLast={handleUndoLastGenerated}
        onRedoLast={handleRedoLastGenerated}
        loading={loading}
      />
    </div>
  );
}