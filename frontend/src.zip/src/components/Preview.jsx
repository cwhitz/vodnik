import React from "react";
import ReactMarkdown from "react-markdown";

export default function Preview({ text, mediaMap }) {
  return (
    <div className="flex flex-col h-full w-full overflow-hidden">
      <div className="flex-1 p-4 overflow-auto">
        <div className="preview-container w-full h-full rounded-xl border border-neutral-700 bg-black p-4 text-neutral-200 overflow-auto">
          <ReactMarkdown
            children={text}
            components={{
              // Custom paragraph handler to preserve line breaks
              p({ children }) {
                // Ensure children is always an array
                const items = Array.isArray(children) ? children : [children];

                return (
                  <p className="mb-2">
                    {items.map((child, i) => {
                      if (typeof child === "string") {
                        // Split by \n and insert <br />
                        return child.split("\n").map((line, j) => (
                          <React.Fragment key={`${i}-${j}`}>
                            {j > 0 && <br />}
                            {line}
                          </React.Fragment>
                        ));
                      }
                      return child; // leave React elements unchanged
                    })}
                  </p>
                );
              },
              img({ src, alt }) {
                const actualSrc = mediaMap[src] || src;
                return (
                  <div className="flex justify-center my-2">
                    <img
                      src={actualSrc}
                      alt={alt}
                      className="rounded-md max-w-full max-h-[80vh] object-contain"
                    />
                  </div>
                );
              },
              a({ href, children }) {
                if (mediaMap[href]) {
                  return (
                    <div className="flex justify-center my-2">
                      <video
                        controls
                        src={mediaMap[href]}
                        className="rounded-md max-w-full max-h-[80vh] object-contain"
                      />
                    </div>
                  );
                }
                return <a href={href}>{children}</a>;
              },
            }}
          />
        </div>
      </div>
    </div>
  );
}
