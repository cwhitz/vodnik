import JSZip from "jszip";

export async function loadStory(file, setText, setMediaMap, setLoreItems) {
  const zip = await JSZip.loadAsync(file);
  
  // Load Markdown
  const markdownFile = zip.file("story.md");
  if (!markdownFile) return;

  const text = await markdownFile.async("string");
  setText(text);

  // Load lore
  const loreFile = zip.file("lore.json");
  if (loreFile) {
    const loreText = await loreFile.async("string");
    const loreData = JSON.parse(loreText);
    setLoreItems(loreData);
  } else {
    // If no lore file, initialize with one blank item
    setLoreItems([{ id: Date.now(), category: "character", text: "" }]);
  }

  // Load media
  const mediaFolder = zip.folder("media");
  const newMediaMap = {};

  if (mediaFolder) {
    const files = Object.values(mediaFolder.files);
    for (const f of files) {
      const blob = await f.async("blob");
      const id = f.name.split("/").pop().split(".")[0]; // extract id
      const url = URL.createObjectURL(blob);
      newMediaMap[id] = url;
    }
  }

  setMediaMap(newMediaMap);
}