import { useState, useRef, useEffect } from "react";

export default function DropdownButton({ label, options }) {
  const [open, setOpen] = useState(false);
  const dropdownRef = useRef(null);

  useEffect(() => {
    function handleClickOutside(event) {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target)) {
        setOpen(false);
      }
    }
    document.addEventListener("mousedown", handleClickOutside);
    return () => document.removeEventListener("mousedown", handleClickOutside);
  }, []);

  return (
    <div className="relative" ref={dropdownRef}>
      <button
        className="hacker-button"
        onClick={() => setOpen(!open)}
      >
        {label}
      </button>
      {open && (
        <div className="absolute right-0 mt-2 w-48 bg-neutral-900 border border-neutral-700 rounded-xl z-50">
          {options.map((opt, idx) => (
            <button
              key={idx}
              className="hacker-button w-full rounded-none"
              onClick={() => {
                opt.onClick();
                setOpen(false);
              }}
            >
              {opt.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
