export default function EditorToolbar({ onNewStory, onAddMedia, onEditLore }) {
  return (
    <div className="p-4 flex gap-2 border-b border-neutral-700">
      <button className="hacker-button flex-1 text-center" onClick={onNewStory}>
        New Story
      </button>

      <label
        htmlFor="fileUpload"
        className="hacker-button flex-1 text-center cursor-pointer"
        onClick={onAddMedia}
      >
        Add Media
      </label>
      <input
        id="fileUpload"
        type="file"
        multiple
        accept="image/*,video/*"
        className="hidden"
      />

      <button className="hacker-button flex-1 text-center" onClick={onEditLore}>
        Edit Lore
      </button>
    </div>
  );
}
