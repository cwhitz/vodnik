import { useEffect, useRef, useState } from "react";

import TopBar from "./components/TopBar";
import Editor from "./components/Editor";
import Preview from "./components/Preview";
import Settings from "./components/Settings";

import { saveStory, loadStory } from "./storage";
import "./buttons.css";

export default function App() {
  /* =======================
     State
  ======================= */
  const [text, setText] = useState("");
  const [additionalInstructions, setAdditionalInstructions] = useState("");
  const [wordCount, setWordCount] = useState(50);

  const [fullScreenPreview, setFullScreenPreview] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [loading, setLoading] = useState(false);

  const [mediaMap, setMediaMap] = useState({});
  const [lastGeneratedRange, setLastGeneratedRange] = useState<{
    start: number;
    end: number;
  } | null>(null);
  const [lastGenerationRequest, setLastGenerationRequest] = useState<any>(null);

  const [loreItems, setLoreItems] = useState([
    { id: Date.now(), category: "character", text: "" },
  ]);

  const textareaRef = useRef<HTMLTextAreaElement | null>(null);

  /* =======================
     Derived state
  ======================= */
  const isDirty = text.length > 0;

  /* =======================
     Effects
  ======================= */
  useEffect(() => {
    if (!isDirty) return;

    const handler = (event: BeforeUnloadEvent) => {
      event.preventDefault();
      event.returnValue = "";
    };

    window.addEventListener("beforeunload", handler);
    return () => window.removeEventListener("beforeunload", handler);
  }, [isDirty]);

  /* =======================
     Actions (your handlers)
  ======================= */
  const handleGenerateNextLine = async () => {
    if (!textareaRef.current) return;
    setLoading(true);

    try {
      const payload = {
        text,
        additional_instructions: additionalInstructions,
        word_count: wordCount,
      };

      const response = await fetch("http://127.0.0.1:8000/generate/next", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error("API request failed");
      const data = await response.json();
      const generated = " " + data.generated_text;

      setText((prev) => {
        const start = prev.length;
        const end = prev.length + generated.length;

        setLastGeneratedRange({ start, end });
        setLastGenerationRequest({ type: "next" });

        return prev + generated;
      });
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  const handleGenerateBetween = async () => {
    if (!textareaRef.current) return;
    setLoading(true);

    try {
      const textarea = textareaRef.current;
      const startPos = textarea.selectionStart;
      const endPos = textarea.selectionEnd;

      const payload = {
        text,
        additional_instructions: additionalInstructions,
        word_count: wordCount,
        start_position: startPos,
        end_position: endPos,
      };

      const response = await fetch("http://127.0.0.1:8000/generate/between", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      if (!response.ok) throw new Error("API request failed");
      const data = await response.json();
      const generatedText = data.generated_text;

      const newText =
        text.slice(0, startPos) + generatedText + text.slice(endPos);
      setText(newText);

      setLastGeneratedRange({
        start: startPos,
        end: startPos + generatedText.length,
      });

      setLastGenerationRequest({
        type: "between",
        startPos,
        endPos,
      });

      const newCursor = startPos + generatedText.length;
      setTimeout(() => {
        textarea.focus();
        textarea.setSelectionRange(newCursor, newCursor);
      }, 0);
    } catch (err) {
      console.error("Error generating between:", err);
    } finally {
      setLoading(false);
    }
  };

  const handleUndoLastGenerated = () => {
    if (!lastGeneratedRange) return;

    const { start, end } = lastGeneratedRange;
    setText((prev) => (prev.slice(0, start) + prev.slice(end)).trimEnd());
  };

  const handleRedoLastGenerated = async () => {
    if (!lastGenerationRequest) return;

    const { type, startPos, endPos } = lastGenerationRequest;

    if (lastGeneratedRange) {
      const { start, end } = lastGeneratedRange;
      setText((prev) => (prev.slice(0, start) + prev.slice(end)).trimEnd());
    }

    if (type === "next") {
      await handleGenerateNextLine();
    } else if (type === "between") {
      if (textareaRef.current) {
        textareaRef.current.focus();
        textareaRef.current.setSelectionRange(startPos, endPos);
      }
      await handleGenerateBetween();
    }
  };

  /* =======================
     Render (your existing JSX)
  ======================= */
  return (
    <div className="flex flex-col h-screen w-screen bg-black text-neutral-200">
      <TopBar
        setText={setText}
        setSettingsOpen={setSettingsOpen}
        saveStory={() => saveStory(text, mediaMap, loreItems)}
        loadStory={(file) => loadStory(file, setText, setMediaMap, setLoreItems)}
      />

      {settingsOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-70 flex items-center justify-center z-50">
          <div className="bg-neutral-900 p-6 rounded-xl w-1/3 relative">
            <button
              className="absolute top-2 right-2 text-neutral-200"
              onClick={() => setSettingsOpen(false)}
            >
              ✖
            </button>

            <Settings
              savedTokens={{}}
              onSave={(tokens) => {
                console.log("Tokens saved:", tokens);
              }}
            />
          </div>
        </div>
      )}

      <div className="flex flex-1 overflow-hidden">
        {!fullScreenPreview && (
          <Editor
            text={text}
            setText={setText}
            additionalInstructions={additionalInstructions}
            setAdditionalInstructions={setAdditionalInstructions}
            wordCount={wordCount}
            setWordCount={setWordCount}
            handleGenerateNextLine={handleGenerateNextLine}
            handleGenerateBetween={handleGenerateBetween}
            handleUndoLastGenerated={handleUndoLastGenerated}
            handleRedoLastGenerated={handleRedoLastGenerated}
            mediaMap={mediaMap}
            setMediaMap={setMediaMap}
            textareaRef={textareaRef}
            loading={loading}
            loreItems={loreItems}
            setLoreItems={setLoreItems}
          />
        )}

        <div
          className={`flex flex-col h-full ${
            fullScreenPreview ? "w-full" : "w-1/2"
          }`}
        >
          <Preview
            text={text}
            mediaMap={mediaMap}
            lastGeneratedRange={lastGeneratedRange}
          />
          <div className="p-4 border-t border-neutral-700">
            <button
              className="hacker-button w-full"
              onClick={() => setFullScreenPreview(!fullScreenPreview)}
            >
              {fullScreenPreview ? "Exit Full Screen" : "Full screen preview"}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
