// Clean up unused media URLs
export function cleanupMedia(mediaMap, text, setMediaMap) {
  const usedIds = Array.from(text.matchAll(/\((img|vid)-\d+\)/g)).map((m) => m[0].slice(1, -1));
  setMediaMap((prev) => {
    const newMap = {};
    Object.entries(prev).forEach(([id, url]) => {
      if (usedIds.includes(id)) {
        newMap[id] = url;
      } else {
        URL.revokeObjectURL(url);
      }
    });
    return newMap;
  });
}
